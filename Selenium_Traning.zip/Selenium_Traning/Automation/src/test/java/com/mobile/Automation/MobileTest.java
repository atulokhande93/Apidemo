package com.mobile.Automation;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.aspectj.util.FileUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MobileTest {
	
	public static AppiumDriver<MobileElement> driver = null;
	MobileConnection config = new MobileConnection();
	
	@BeforeTest(enabled=true)
	public void lanchdriver() throws MalformedURLException
	{
		
		driver = config.getDriver();
	}
	
	
	@Test(enabled=true)
	public void whatsapp() throws InterruptedException, IOException
	{
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//android.view.View[@content-desc='row 0column 0']")).click();
		driver.findElement(By.xpath("//android.view.View[@content-desc='row 0column 2']")).click();
		driver.findElement(By.xpath("//android.view.View[@content-desc='row 3column 1']")).click();
		driver.findElement(By.xpath("//android.view.View[@content-desc='row 1column 1']")).click();
		Thread.sleep(10000);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		TakesScreenshot sc = (TakesScreenshot)driver;
		File filesc = sc.getScreenshotAs(OutputType.FILE);
		
		FileUtil.copyFile(filesc, new File("B:/ATUL/abc.png"));
	}
	
	
	
	
	@Test(enabled=false)
	public void gaana() throws InterruptedException
	{
		//Thread.sleep(60000);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//android.widget.TextView[@content-desc='Settings']")).click();
	}
	
	
	@Test(enabled=false)
	public void testBrwoser() throws InterruptedException
	{
		Thread.sleep(60000);
		driver.get("https://www.facebook.com");
	}
	
	@Test(enabled=false)
	public void testCalculator()
	{
		WebElement ele = driver.findElement(By.name("2"));
		ele.click();
		
		WebElement ele1 = driver.findElement(By.name("4"));
		ele1.click();
		
		WebElement ele3 = driver.findElement(By.name("+"));
		ele3.click();
		
		WebElement ele4 = driver.findElement(By.name("7"));
		ele4.click();
		
		
		WebElement ele6 = driver.findElement(By.name("="));
		ele6.click();
		
		WebElement result = driver.findElement(By.tagName("EditText"));
		
		System.out.println("Total : "+result.getText());
	}

	

}
