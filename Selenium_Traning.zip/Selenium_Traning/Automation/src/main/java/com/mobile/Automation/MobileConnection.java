package com.mobile.Automation;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;



public class MobileConnection 
{
	
	public DesiredCapabilities setAppCapabilities()
	{
		DesiredCapabilities capa = new DesiredCapabilities();
//		capa.setCapability(CapabilityType.BROWSER_NAME, "Chrome");
		capa.setCapability(CapabilityType.VERSION, "7.1.1");
		capa.setCapability(CapabilityType.PLATFORM_NAME, "Android");
		capa.setCapability("deviceName", "d0e5e4c5");
		
		capa.setCapability("appPackage", "com.oppo.camera");
		capa.setCapability("appActivity", "com.oppo.camera.Camera");
		
//		capa.setCapability("appPackage", "com.gaana");
//		capa.setCapability("appActivity", "com.gaana.GaanaActivity");
		
//		capa.setCapability("appPackage", "com.whatsapp");
//		capa.setCapability("appActivity", "com.whatsapp.Main");
		
//		capa.setCapability("skipDeviceInitialization", "true");
//		capa.setCapability("skipServerInstallation", "true");
		capa.setCapability("noReset", "true");
		
		return capa;
	}
	
	
	public DesiredCapabilities setWebCapabilities()
	{
		System.setProperty("webdriver.chrome.driver", "B:\\driver\\chromedriver.exe");
		
		DesiredCapabilities capa = new DesiredCapabilities();
		capa.setCapability(CapabilityType.BROWSER_NAME, "chrome");
		capa.setCapability(CapabilityType.VERSION, "7.1.1");
		capa.setCapability(CapabilityType.PLATFORM_NAME, "Android");
		capa.setCapability("deviceName", "d0e5e4c5");
		
		capa.setCapability("skipDeviceInitialization", "true");
		capa.setCapability("skipServerInstallation", "true");
		capa.setCapability("noReset", "true");
		

		
		return capa;
	}
	
	public AppiumDriver<MobileElement> getDriver() throws MalformedURLException
	{
		//WebDriver driver =  new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"),setAppCapabilities());
		
		AppiumDriver<MobileElement> driver = null;
		
		//driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"),setWebCapabilities());
		
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"),setAppCapabilities());
		
		return driver;
	}
}
