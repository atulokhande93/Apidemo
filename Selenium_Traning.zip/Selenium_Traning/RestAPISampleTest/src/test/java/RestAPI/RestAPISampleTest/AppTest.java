package RestAPI.RestAPISampleTest;

import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.AuthenticationSpecification;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
//    @Test
//    public void get()
//    {
//    	RestAssured.baseURI="https://reqres.in";
//        RestAssured.basePath="/api/{abc}/{id}";
//        
//        RequestSpecification re = RestAssured.given();
//        AuthenticationSpecification as= re.auth();
//        re.pathParam("abc", "users");
//        re.pathParam("id", "2");
//        re.param("page", "2");
//	re.when();
//        Response res = re.get();
//       
//        System.out.println(res.asString());
//    }
    
    @Test
    public void post()
    {
    	RestAssured.baseURI="https://reqres.in";
    	RestAssured.basePath="/api/{abc}";
    	RequestSpecification re = RestAssured.given();
    	re.contentType(ContentType.JSON);
    	re.pathParam("abc", "users");
    	Map<String, String> data = new HashMap<>();
    	
    	data.put("name", "morpheus");
    	data.put("job", "sds");
    	re.body(data);
    	re.when();
    	Response res= re.put();
    	 System.out.println(res.time());
    	 
    	 
    	 QueryableRequestSpecification dc = SpecificationQuerier.query(re);
    	System.out.println(dc.getDerivedPath());
    }
}
