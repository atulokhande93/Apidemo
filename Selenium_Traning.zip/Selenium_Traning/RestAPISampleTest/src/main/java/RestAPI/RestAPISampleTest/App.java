package RestAPI.RestAPISampleTest;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        RestAssured.baseURI="https://reqres.in";
        RestAssured.basePath="/api/users/{id}";
        
        RequestSpecification re = RestAssured.given();
        re.pathParam("id", "2");
        re.param("page", "2");
        Response res = re.get();
        System.out.println(res.asString());
    }
}
