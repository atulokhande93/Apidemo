package com.selenium.training;

import java.io.StringReader;

import javax.json.Json;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;







import org.json.simple.parser.JSONParser;
import org.testng.annotations.Test;

public class ApiTest 
{
	
	@Test
	public void testApi()
	{
		RestAssured.baseURI="http://restapi.demoqa.com/utilities/weather/city";	
		RequestSpecification resp = RestAssured.given();
		Response res = resp.request(Method.GET,"/Hyderabad");
		String responseBody = res.getBody().asString();
		responseBody = "["+responseBody+","+responseBody+"]";
		System.out.println("Api Body : "+responseBody);
		jsonString(responseBody);
	
	}
	
	public void jsonString(String responseBody)
	{
		
		JsonParser parse = Json.createParser(new StringReader(responseBody));
		Event even;
		
		
		
		while(parse.hasNext())
		{
			even = parse.next();
			if(even == Event.START_OBJECT)
			{
				System.out.println("Start of Json");
			}
			else if(even == Event.END_OBJECT)
			{
				
				System.out.println("End of Json");
				
			}
			else if(even == Event.KEY_NAME)
			{
				System.out.println("Key from Json : "+parse.getString());
			}
				
			else if(even == Event.VALUE_STRING || even==Event.VALUE_NUMBER)
			{
				System.out.println("Value from Json : "+parse.getString());
			}
			
		}
	}
	
}
