import org.testng.Assert;
import org.testng.annotations.Test;



public class DemoClass {
	
	@Test
	public void add()
	{
		Assert.assertTrue(true);
		System.out.println("Addiion of no in a class");
	}
	
	


}
