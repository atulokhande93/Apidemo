package selenium.common.utilities;

public class DemoClass {
	
	public void add()
	{
		System.out.println("Addiion of no");
	}
	
	
	public static void main(String args[])
	{
		DemoClass dm = new DemoClass();
		dm.add();
	}

}
