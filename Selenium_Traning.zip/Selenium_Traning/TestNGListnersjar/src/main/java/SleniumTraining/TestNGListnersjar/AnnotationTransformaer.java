package SleniumTraining.TestNGListnersjar;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.internal.runners.TestMethod;
import org.testng.IAnnotationTransformer;
import org.testng.annotations.DataProvider;
import org.testng.annotations.ITestAnnotation;

public class AnnotationTransformaer implements IAnnotationTransformer{
	
	
	@Override
	public void transform(ITestAnnotation annotation, Class testClass,Constructor testConstructor, Method testMethod) {
		
		if(testMethod.isAnnotationPresent(ExcelInput.class))
		{
			ExcelInput in = testMethod.getAnnotation(ExcelInput.class);
			System.out.println("File Name : "+in.FileName());
			System.out.println("Data Provider : "+in.Dataprovider());
			System.out.println("Sheet name : "+in.SheetName());
			
			
			annotation.setDataProvider(in.Dataprovider());
			
			
		}
		
	}

	
	 @DataProvider(name="excelDataprovider")
	    public Object[] excelData(Method m) throws FileNotFoundException, IOException
	    {
		 
		 String ExcelFilename = m.getAnnotation(ExcelInput.class).FileName();
		 String Sheetname = m.getAnnotation(ExcelInput.class).SheetName();
		 
	    	List<Map<String, String>> maplist = new ArrayList<>();
	    	Map<String,String> dataMap;
	    	
	    	File excelFile = new File("C:\\Users\\Selenium_Traning\\"+ExcelFilename+".xlsx");
	    	
	    	FileInputStream in = new FileInputStream(excelFile);
	    	
	    	XSSFWorkbook workbk = new XSSFWorkbook(in);
	    	XSSFSheet sheet = workbk.getSheet(Sheetname);
	    	System.out.println("sheet rows : "+sheet.getLastRowNum());
	    	Row dataName = sheet.getRow(0);
	    	Row dataValue;
	    	
	    	for(int i=1;i<=sheet.getLastRowNum();i++)
	    	{
	    		dataMap = new HashMap<String,String>();
	    		dataValue= sheet.getRow(i);
	    		for(int j=0;j<dataName.getLastCellNum();j++)
	    		{
	    			//System.out.println("dataName : "+dataName.getCell(j).getStringCellValue()+" : dataValue : "+dataValue.getCell(j).getStringCellValue());
	    			dataMap.put(dataName.getCell(j).getStringCellValue(), dataValue.getCell(j).getStringCellValue());
	    		}
	    		maplist.add(dataMap);
	    		//dataMap.clear();
	    	}
	    	
	    	
	    	Object[] abc =  maplist.toArray(new Object[maplist.size()]);
	    	
	    	//Object[][] abc =  (Object[][]) maplist.toArray(new maplis);
	   
	    	return abc;
	    	
			
	    	
	    	
	    }

}
