package SleniumTraining.ReflectionDemo;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;



@Aspect
public class AspectInjector 
{
	
	@Pointcut("execution(* ActionsClass.OpenBrowser(..))")
	public void callmethod()
	{
		
	}
	
	@After("callmethod()")
	public void assertMethod(JoinPoint jp)
	{
		System.out.println("calling method asser");
	}

	@Pointcut("call(static * org.testng.Assert.assert*(..)) || call(static * org.testng.Assert.SoftAssert.assertAll())")
	public void assertThat(){
	}
	
	@After("assertThat()")
	public void reportAssert(JoinPoint jp)
	{
	
		System.out.println("calling on assertion");
	}
	
}
