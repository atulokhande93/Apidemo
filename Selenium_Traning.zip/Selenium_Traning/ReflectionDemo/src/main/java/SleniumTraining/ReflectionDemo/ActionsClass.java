package SleniumTraining.ReflectionDemo;

import org.testng.Assert;
import org.testng.asserts.SoftAssert;



/**
 * Hello world!
 *
 */
public class ActionsClass 
{

  
	public static void OpenBrowser(String url)
	{
		Assert.assertTrue(true);
		System.out.println("In OpenBrowser  "+url);
	}
	
	public static void ClickonBtn(String xpath)
	{
		SoftAssert asw = new SoftAssert();
		asw.assertTrue(true);
		System.out.println("In ClickonBtn  "+xpath);
		asw.assertAll();
	}
	
}
