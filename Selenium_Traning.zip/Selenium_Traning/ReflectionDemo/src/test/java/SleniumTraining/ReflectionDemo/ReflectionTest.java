package SleniumTraining.ReflectionDemo;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import SleniumTraining.TestNGListnersjar.ExcelInput;




/**
 * Unit test for simple App.
 */
public class ReflectionTest 
{

	ActionsClass action = new ActionsClass();
	
	
	@ExcelInput(FileName="TestData",SheetName="demo")
    @Test(enabled=true)
    public void Demo(Map<String, String> input) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException 
    {
    	Class cls = action.getClass();	
    	
   
    	
    	Method actions[] = cls.getDeclaredMethods();
    	
    	for(Method act : actions)
    	{
    		//System.out.println("All Metthods : "+act.getName());
    		
    		if(act.getName().equals(input.get("Action")))
    		{
    			//Method acme = cls.getMethod(input.get("Action"),String.class);
    			act.invoke(input.get("Action"), input.get("Xpath"));
    		}
    		
    		
    	}
    	
    }
    
//    @ExcelInput(FileName="TestData",SheetName="demo")
//    @Test(enabled=true)
//    public void Democ() throws IllegalAccessException, IllegalArgumentException, NoSuchMethodException, SecurityException, InvocationTargetException
//    {
//    	
//    }
    
    	@DataProvider(name="excelDataprovider")
	   // @Test
	    public Object[] excelData() throws FileNotFoundException, IOException
	    {
	    	List<Map<String, String>> maplist = new ArrayList<>();
	    	Map<String,String> dataMap;
	    	

	    	File excelFile = new File("C:\\Users\\A\\Selenium_Traning\\TestData.xlsx");
	    	
	    	FileInputStream in = new FileInputStream(excelFile);
	    	
	    	XSSFWorkbook workbk = new XSSFWorkbook(in);
	    	XSSFSheet sheet = workbk.getSheet("demo");
	    	System.out.println("sheet rows : "+sheet.getLastRowNum());
	    	Row dataName = sheet.getRow(0);
	    	Row dataValue;
	    	
	    	for(int i=1;i<=sheet.getLastRowNum();i++)
	    	{
	    		dataMap = new HashMap<String,String>();
	    		dataValue= sheet.getRow(i);
	    		for(int j=0;j<dataName.getLastCellNum();j++)
	    		{
	    			//System.out.println("dataName : "+dataName.getCell(j).getStringCellValue()+" : dataValue : "+dataValue.getCell(j).getStringCellValue());
	    			dataMap.put(dataName.getCell(j).getStringCellValue(), dataValue.getCell(j).getStringCellValue());
	    		}
	    		maplist.add(dataMap);
	    		//dataMap.clear();
	    	}
	    	
	    	
	    	Object[] abc =  maplist.toArray(new Object[maplist.size()]);
	    	
	    	//Object[][] abc =  (Object[][]) maplist.toArray(new maplis);
	   
	    	return abc;
	    	
			
	    	
	    	
	    }

   
}
